import React from "react";
import { Chart } from "react-google-charts";

// eslint-disable-next-line react-refresh/only-export-components
export const data = [
  [
    "Month",
    "Bolivia",
    "Ecuador",
    "Madagascar",
    "Papua New Guinea",
    "Rwanda",
    "Average",
  ],
  ["2004/05", 165, 938, 522, 998, 450, 614.6],
  ["2005/06", 135, 1120, 599, 1268, 288, 682],
  ["2006/07", 157, 1167, 587, 807, 397, 623],
  ["2007/08", 139, 1110, 615, 968, 215, 609.4],
  ["2008/09", 136, 691, 629, 1026, 366, 569.6],
];

// eslint-disable-next-line react-refresh/only-export-components
export const options = {
  title: "Graphique Evolution Ventes 7 Derniers Jours",
  vAxis: { title: "Cups" },
  hAxis: { title: "Month" },
  seriesType: "bars",
  series: { 5: { type: "line" } },
};

export default function Barchart() {
  return (
    <Chart
      chartType="ComboChart"
      width="100%"
      height="300px"
      data={data}
      options={options}
    />
  );
}
