const SalesList = () => {
    return ( 
        <>
        
        </>
     );
}
 
export default SalesList;