const AddSales = () => {
    return ( 
        <>
        
        </>
     );
}
 
export default AddSales;