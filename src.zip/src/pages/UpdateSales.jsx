const UpdateSales = () => {
    return ( 
        <>
        
        </>
     );
}
 
export default UpdateSales;