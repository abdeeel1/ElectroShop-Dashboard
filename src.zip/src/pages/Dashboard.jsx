import Barchart from "../charts/BarChart";
import Sidebar from "../components/Layout/Sidebar";
import LocalAtmIcon from '@mui/icons-material/LocalAtm';
const Dashboard = () => {
    
    
    return ( 
        <div>
            
            <div className="grid grid-cols-1 space-y-4 md:grid-cols-2 md:space-y-4 md:gap-4">
                <div className="bg-gradient-to-r h-35  from-blue-500 to-blue-600 p-4 flex flex-col space-y-2 rounded-2xl">
                    <LocalAtmIcon sx={{color:"white"}}/>
                    <p className="font-bold text-white">500.00DH</p>
                    <p className="font-semibold text-white">💰CA du Jour</p>

                </div>
                <div className="bg-gradient-to-r h-35  from-green-500 to-emerald-500 p-4 flex flex-col space-y-2 rounded-2xl">
                    <LocalAtmIcon sx={{color:"white"}}/>
                    <p className="font-bold text-white">500.00DH</p>
                    <p className="font-semibold text-white">💰CA du Mois</p>

                </div>
                <div className="bg-gradient-to-r  h-35  from-red-800 to-red-400 p-4 flex flex-col space-y-2 rounded-2xl">
                    <LocalAtmIcon sx={{color:"white"}}/>
                    <p className="font-bold text-white">500.00DH</p>
                    <p className="font-semibold text-white">💰CA du Total</p>

                </div>
                <div className="bg-gradient-to-r h-35   from-neutral-700 to-black p-4 flex flex-col space-y-2 rounded-2xl">
                    <LocalAtmIcon sx={{color:"white"}}/>
                    <p className="font-bold text-white">500.00DH</p>
                    <p className="font-semibold text-white">🛒Panier Moyen</p>
                </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-4">
                <div className="lg:col-span-3">
                    <Barchart/>
                </div>
                <div>
                    <h5 className="font-bold text-center  font-sans w-full mb-5">Top Produits</h5>
                    <div className="overflow-x-auto">
                    <table className="table table-xs">
                        <thead>
                        <tr>
                            <th></th>
                            <th>Name</th>
                            <th>Job</th>
                            <th>company</th>
                            <th>location</th>
                            <th>Last Login</th>
                            <th>Favorite Color</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <th>1</th>
                            <td>Cy Ganderton</td>
                            <td>Quality Control Specialist</td>
                            <td>Littel, Schaden and Vandervort</td>
                            <td>Canada</td>
                            <td>12/16/2020</td>
                            <td>Blue</td>
                        </tr>
                        <tr>
                            <th>2</th>
                            <td>Hart Hagerty</td>
                            <td>Desktop Support Technician</td>
                            <td>Zemlak, Daniel and Leannon</td>
                            <td>United States</td>
                            <td>12/5/2020</td>
                            <td>Purple</td>
                        </tr>
                        <tr>
                            <th>3</th>
                            <td>Brice Swyre</td>
                            <td>Tax Accountant</td>
                            <td>Carroll Group</td>
                            <td>China</td>
                            <td>8/15/2020</td>
                            <td>Red</td>
                        </tr>
                        <tr>
                            <th>4</th>
                            <td>Marjy Ferencz</td>
                            <td>Office Assistant I</td>
                            <td>Rowe-Schoen</td>
                            <td>Russia</td>
                            <td>3/25/2021</td>
                            <td>Crimson</td>
                        </tr>
                        <tr>
                            <th>5</th>
                            <td>Yancy Tear</td>
                            <td>Community Outreach Specialist</td>
                            <td>Wyman-Ledner</td>
                            <td>Brazil</td>
                            <td>5/22/2020</td>
                            <td>Indigo</td>
                        </tr>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
     );
}
 
export default Dashboard;