import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const fetchSales = createAsyncThunk(
  "sales/fetch",
  async () => {
    const response = await axios.get("http://localhost:8000/sales");
    return response.data;
  }
);

export const addSale = createAsyncThunk(
  "sales/add",
  async (saleData) => {
    const response = await axios.post("http://localhost:8000/sales", saleData);
    return response.data;
  }
);

const salesSlice = createSlice({
  name: "sales",
  initialState: [],
  reducers: {
    deleteSale: (state, action) => {
      return state.filter(sale => sale.id !== action.payload);
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchSales.fulfilled, (state, action) => {
        return action.payload;
      })
      .addCase(addSale.fulfilled, (state, action) => {
        state.unshift(action.payload); // Ajoute au début
      });
  }
});

export const { deleteSale } = salesSlice.actions;
export default salesSlice.reducer;