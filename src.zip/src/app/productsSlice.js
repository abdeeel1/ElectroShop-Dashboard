import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const fetchProducts = createAsyncThunk(
  "products/fetch",
  async () => {
    const response = await axios.get("http://localhost:8000/products");
    return response.data;
  }
);

const productsSlice = createSlice({
  name: "products",
  initialState: [],
  reducers: {
    addProduct: (state, action) => {
      state.push(action.payload);
    },
    updateProduct: (state, action) => {
      const { id, ...updatedData } = action.payload;
      const index = state.findIndex(product => product.id === id);
      if (index !== -1) state[index] = { ...state[index], ...updatedData };
    },
    deleteProduct: (state, action) => {
      return state.filter(product => product.id !== action.payload);
    }
  },
  extraReducers: (builder) => {
    builder.addCase(fetchProducts.fulfilled, (state, action) => {
      return action.payload;
    });
  }
});

export const { addProduct, updateProduct, deleteProduct } = productsSlice.actions;
export default productsSlice.reducer;